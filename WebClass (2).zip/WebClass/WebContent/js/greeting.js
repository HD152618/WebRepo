/**
 * 
 */
[hello.js]
alert("안녕하세요?");